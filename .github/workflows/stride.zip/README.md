# Stride: half marathon plan

Home Screen web app for your Nov 8, 2026 to Apr 3, 2027 plan: running, strength, mobility and recovery, analytics, and predictions.

## Files (upload all of them)

- `index.html`: the app
- `manifest.webmanifest`: app name and icons
- `sw.js`: lets the app open without signal
- `apple-touch-icon.png`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`: icons

## Put it on GitHub Pages

1. On github.com, create a new public repository, for example `stride`.
2. Choose **Add file > Upload files**, select all seven files above, and commit.
3. Open **Settings > Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**, pick **main** and **/ (root)**, then **Save**.
4. After a minute or two the app is live at `https://YOUR-USERNAME.github.io/stride/`.

## Add it to your Home Screen

1. Open that link in **Safari** on your iPhone.
2. Tap **Share > Add to Home Screen**, then **Add**.
3. Log everything from the Home Screen app. Safari may keep a separate copy of your data.

## Bring over your old app's data

Your runs from Oct 25 to Nov 7 are already loaded. To add the rest:

1. In the old app, open **Back up or restore progress** and tap **Copy backup code**.
2. In Stride, tap the sliders button at the top right, paste the code, and tap **Restore from code**.

Old runs are imported as pre-plan history. Lift check-offs from the old app aren't carried over.

## Keep a backup

Progress is saved on your phone only. Every week or so, open Settings and tap **Copy backup code**, then paste it into a note or email. **Restore from code** brings everything back.

## Updating the app later

Replace `index.html` in the repository. The app picks up the new version the next time it opens with a signal. If you install it into the same repository as an older app, delete the old Home Screen icon and add it again so the new icon and name show.
